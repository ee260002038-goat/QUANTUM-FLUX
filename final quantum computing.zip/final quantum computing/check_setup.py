"""Run first:  python check_setup.py   -> confirms you have the CORRECT simulator and solver."""
import json
from solution.traffic_model import simulate_traffic, build_qubo_matrix
S = json.load(open("scenario_R.json"))
exp = {"10101010": 116.0, "11111111": 146.0, "00000000": 237.0, "01111001": 92.5}
ok = True
for b, e in exp.items():
    got = simulate_traffic([int(c) for c in b], S)
    print(b, got, "expected", e, "OK" if got == e else "WRONG"); ok &= got == e
import inspect, solution.qaoa_solver as q
has_norm = "E.std()" in inspect.getsource(q.run_qaoa_pipeline); print("solver normalises Q:", has_norm)
print("ALL GOOD" if ok and has_norm else "OLD FILES STILL IN USE")
