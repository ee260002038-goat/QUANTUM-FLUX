"""Official traffic model + scenario-independent QUBO construction."""
import itertools
import numpy as np

ALL_BITS = np.array(list(itertools.product([0, 1], repeat=8)), dtype=int)  # row idx == int of bitstring x0..x7
PAIRS = [(i, j) for i in range(8) for j in range(i + 1, 8)]


def simulate_traffic(bits, sc):
    """Exact model of Sec. 3/5. bits = [A1..A4, B1..B4]; 1 = NS green, 0 = EW green.
    Transfers A->B are floor(frac*departures+0.5) and enter B at the START of the NEXT slot."""
    cap, st = sc["capacity"], sc["storage"]
    wo, ws = sc["overflow_weight"], sc["switch_weight"]
    app, fr = sc["link"]["approach"], sc["link"]["fraction"]
    qA = {"NS": 0, "EW": 0}; qB = {"NS": 0, "EW": 0}
    pending = 0
    delay = overflow = switches = 0
    for t in range(4):
        for k in ("NS", "EW"):
            qA[k] += sc["A_arrivals"][k][t]
            qB[k] += sc["B_arrivals"][k][t]
        qB[app] += pending                     # transfer from the preceding slot
        gA = "NS" if bits[t] == 1 else "EW"
        served = min(qA[gA], cap); qA[gA] -= served
        pending = int(np.floor(fr * served + 0.5)) if gA == app else 0
        gB = "NS" if bits[4 + t] == 1 else "EW"
        qB[gB] -= min(qB[gB], cap)
        for v in (*qA.values(), *qB.values()):
            delay += v
            overflow += max(0, v - st)
        if t > 0:
            switches += int(bits[t] != bits[t - 1]) + int(bits[4 + t] != bits[3 + t])
    return delay + wo * overflow + ws * switches


def _features(X):
    return np.stack([np.ones(len(X))] + [X[:, i] for i in range(8)]
                    + [X[:, i] * X[:, j] for i, j in PAIRS], axis=1)


def build_qubo_matrix(sc, n_init=64, n_round=24, rounds=2, seed=0):
    """Scenario-independent modelling rule: second-order (pairwise) polynomial surrogate of the
    exact traffic cost, because the model's only non-linearities (min(q,cap), max(0,q-storage),
    thresholded transfer) are local in time => dominated by 1- and 2-body terms.
        cost(x) ~ c + sum_i h_i x_i + sum_{i<j} J_ij x_i x_j
    Coefficients = least-squares fit to the simulator on 64 random schedules, then `rounds` of
    active refinement adding the 12 best-predicted unseen schedules per round (88 < 256 evaluations; the
    optimum is never looked up or encoded). Deterministic (fixed fit seed, independent of QAOA seed)."""
    rng = np.random.default_rng(seed)
    ids = list(rng.choice(256, n_init, replace=False))
    y = [simulate_traffic(list(ALL_BITS[i]), sc) for i in ids]
    for r in range(rounds + 1):
        w = np.linalg.lstsq(_features(ALL_BITS[ids]), np.array(y), rcond=None)[0]
        if r == rounds:
            break
        pred = _features(ALL_BITS) @ w
        new = [i for i in np.argsort(pred, kind="stable") if i not in set(ids)][: n_round // 2]
        ids += new; y += [simulate_traffic(list(ALL_BITS[i]), sc) for i in new]
    Q = np.zeros((8, 8))
    for i in range(8): Q[i, i] = w[1 + i]
    for k, (i, j) in enumerate(PAIRS): Q[i, j] = w[9 + k]
    return Q, float(w[0]), len(ids)
