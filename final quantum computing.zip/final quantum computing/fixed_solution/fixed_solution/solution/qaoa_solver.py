"""QAOA for the QUBO: exact NumPy statevector simulation + hand-written OpenQASM 3 export.
Convention: schedule bit x_i lives on qubit (7-i), so the standard Qiskit/QASM bitstring
c[7]..c[0] printed left-to-right IS the schedule A1..A4 B1..B4 (no reversal needed anywhere)."""
import numpy as np
from scipy.optimize import minimize

N = 8
def q_of(i): return N - 1 - i

def energies(Q, offset=0.0):
    """E[idx] = x^T Q x + offset, idx = integer of bitstring x0..x7 (x0 = MSB)."""
    X = np.array([[(k >> (N - 1 - i)) & 1 for i in range(N)] for k in range(2 ** N)])
    return np.einsum("ni,ij,nj->n", X, Q, X) + offset

def ising(Q):
    """x=(1-Z)/2  ->  sum a_i Z_i + sum b_ij Z_i Z_j (+const)."""
    a = np.zeros(N); b = {}
    for i in range(N):
        a[i] -= Q[i, i] / 2
        for j in range(i + 1, N):
            if Q[i, j] != 0:
                b[(i, j)] = Q[i, j] / 4
                a[i] -= Q[i, j] / 4; a[j] -= Q[i, j] / 4
    return a, b

def gate_list(Qn, gammas, betas):
    """Gate list: ('h',q) ('rz',th,q) ('rzz',th,q1,q2) ('rx',th,q). rz(th)=exp(-i th Z/2)."""
    a, b = ising(Qn); g = [("h", q) for q in range(N)]
    for ga, be in zip(gammas, betas):
        for i in range(N):
            if a[i] != 0: g.append(("rz", 2 * ga * a[i], q_of(i)))
        for (i, j), c in b.items(): g.append(("rzz", 2 * ga * c, q_of(i), q_of(j)))
        for q in range(N): g.append(("rx", 2 * be, q))
    return g

def to_qasm3(gates):
    L = ["OPENQASM 3.0;", 'include "stdgates.inc";',
         "gate rzz(p0) a, b {\n  cx a, b;\n  rz(p0) b;\n  cx a, b;\n}", "bit[8] c;", "qubit[8] q;"]
    for g in gates:
        if g[0] == "h": L.append(f"h q[{g[1]}];")
        elif g[0] in ("rz", "rx"): L.append(f"{g[0]}({g[1]:.12f}) q[{g[2]}];")
        else: L.append(f"rzz({g[1]:.12f}) q[{g[2]}], q[{g[3]}];")
    L += [f"c[{k}] = measure q[{k}];" for k in range(N)]
    return "\n".join(L) + "\n"

def state_fast(Ec, gammas, betas):
    """Diagonal cost phase + product mixer (Ec = normalised energies, idx bit k == qubit k)."""
    psi = np.full(2 ** N, 2 ** (-N / 2), dtype=complex)
    ids = np.arange(2 ** N)
    for ga, be in zip(gammas, betas):
        psi = psi * np.exp(-1j * ga * Ec)
        T = psi.reshape([2] * N)
        c, s = np.cos(be), -1j * np.sin(be)
        for ax in range(N):
            T = np.moveaxis(T, ax, 0); T = np.stack([c * T[0] + s * T[1], s * T[0] + c * T[1]]); T = np.moveaxis(T, 0, ax)
        psi = T.reshape(-1)
    return psi

def state_from_gates(gates):
    """Independent gate-by-gate simulation of the exported circuit (consistency check)."""
    T = np.zeros([2] * N, dtype=complex); T[(0,) * N] = 1  # axis a <-> qubit (N-1-a) (big-endian reshape)
    ax = lambda q: N - 1 - q
    def one(U, q):
        nonlocal T
        T = np.moveaxis(np.tensordot(U, np.moveaxis(T, ax(q), 0), axes=(1, 0)), 0, ax(q))
    for g in gates:
        if g[0] == "h": one(np.array([[1, 1], [1, -1]]) / np.sqrt(2), g[1])
        elif g[0] == "rz": one(np.diag([np.exp(-1j * g[1] / 2), np.exp(1j * g[1] / 2)]), g[2])
        elif g[0] == "rx": one(np.array([[np.cos(g[1] / 2), -1j * np.sin(g[1] / 2)], [-1j * np.sin(g[1] / 2), np.cos(g[1] / 2)]]), g[2])
        else:
            z = np.array([1, -1]); sh = [1] * N
            P = np.exp(-1j * g[1] / 2 * np.outer(z, z)).reshape(2, 2, *[1] * (N - 2))
            P = np.exp(-1j * g[1] / 2 * (z[:, None] * z[None, :]))
            full = np.ones([2] * N, dtype=complex)
            s1 = [1] * N; s1[ax(g[2])] = 2; s2 = [1] * N; s2[ax(g[3])] = 2
            full = np.exp(-1j * g[1] / 2 * z.reshape(s1) * z.reshape(s2))
            T = T * full
    return T.reshape(-1)

def run_qaoa_pipeline(sc, Q, offset=0.0, seed=42, p=3, shots=4096, max_evals=300):
    rng = np.random.default_rng(seed)
    E = energies(Q, offset)
    scale = E.std() or 1.0
    Qn = Q / scale; En = (E - E.mean()) / scale           # normalised so gamma ~ O(1)
    Ec = energies(Qn)                                      # phases use the same Q-derived Ising coefficients
    Ec = Ec - Ec.mean()
    # init: linear ramp (annealing-inspired) + seeded jitter
    ramp = (np.arange(p) + 0.5) / p
    x0 = np.concatenate([0.9 * ramp, 0.9 * (1 - ramp)]) + rng.normal(0, 0.05, 2 * p)
    state = {"n": 0}
    def f(x):
        state["n"] += 1
        psi = state_fast(Ec, x[:p], x[p:])
        return float(np.abs(psi) ** 2 @ Ec)               # <H_QUBO>, NOT the official scorer
    res = minimize(f, x0, method="COBYLA", options={"maxiter": max_evals - 1, "rhobeg": 0.3})
    assert state["n"] <= max_evals
    gam, bet = res.x[:p], res.x[p:]
    gates = gate_list(Qn, gam, bet)
    psi = state_fast(Ec, gam, bet)
    # consistency: exported circuit == simulated state (up to global phase)
    psi_g = state_from_gates(gates)
    fid = abs(np.vdot(psi, psi_g)) ** 2
    probs = np.abs(psi) ** 2; probs /= probs.sum()
    samples = rng.choice(2 ** N, size=shots, p=probs)
    counts = {}
    for s in samples:
        k = f"{s:08b}"; counts[k] = counts.get(k, 0) + 1
    return to_qasm3(gates), counts, dict(gammas=gam.tolist(), betas=bet.tolist(), evals=state["n"],
                                         fidelity_gates_vs_fast=float(fid), final_expectation=res.fun)
