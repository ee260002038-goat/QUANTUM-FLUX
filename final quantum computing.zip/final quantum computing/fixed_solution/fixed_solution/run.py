import argparse, json, os
import numpy as np
from solution.traffic_model import build_qubo_matrix, simulate_traffic
from solution.qaoa_solver import run_qaoa_pipeline, energies

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", required=True); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", required=True); ap.add_argument("--p", type=int, default=3)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    sc = json.load(open(a.scenario))
    Q, off, n_eval = build_qubo_matrix(sc)
    json.dump({"qubo_matrix": Q.tolist(), "offset": off, "form": "cost(x) ~ x^T Q x + offset, Q upper-triangular (diag = linear terms)",
               "mapping": {f"x_{i}": f"{'A' if i < 4 else 'B'}_slot{i % 4 + 1} (1=NS,0=EW)" for i in range(8)},
               "auxiliary_variables": [], "qubit_of_variable": {f"x_{i}": 7 - i for i in range(8)},
               "simulator_evaluations_used_to_build_Q": n_eval},
              open(f"{a.out}/qubo.json", "w"), indent=2)
    qasm, counts, info = run_qaoa_pipeline(sc, Q, offset=off, seed=a.seed, p=a.p, shots=4096)
    open(f"{a.out}/circuit.qasm", "w").write(qasm)
    assert sum(counts.values()) == 4096
    json.dump(counts, open(f"{a.out}/counts.json", "w"), indent=2)
    best = min(counts, key=lambda b: (simulate_traffic([int(c) for c in b], sc), b))
    sched = [int(c) for c in best]
    E = energies(Q, off); qmin = [int(c) for c in f"{int(np.argmin(E)):08b}"]
    json.dump({"schedule_bits": sched, "bit_order": "A_slot1..A_slot4 then B_slot1..B_slot4; 1=NS, 0=EW; same order as counts.json keys",
               "official_cost": simulate_traffic(sched, sc), "label": "best of the 4096 raw QAOA samples",
               "qubo_exact_minimizer": {"bits": qmin, "official_cost": simulate_traffic(qmin, sc)},
               "qaoa_info": info}, open(f"{a.out}/schedule.json", "w"), indent=2)
    print("done", a.out)
if __name__ == "__main__": main()
