import json, sys, numpy as np
from solution.traffic_model import build_qubo_matrix, simulate_traffic, ALL_BITS
from solution.qaoa_solver import run_qaoa_pipeline, energies
sc = json.load(open(sys.argv[1])); seeds = [1, 2, 3, 4, 5]
C = np.array([simulate_traffic(list(b), sc) for b in ALL_BITS]); Cs, Cr = C.min(), C.mean()
elite = set(sorted(range(256), key=lambda i: (C[i], i))[:13])
Q, off, n = build_qubo_matrix(sc); E = energies(Q, off); qa = int(E.argmin())
print(f"C*={Cs} ({ALL_BITS[C.argmin()]}) C_rand={Cr:.3f}")
alt = min(simulate_traffic(list(map(int, a + b)), sc) for a in ("1010", "0101") for b in ("1010", "0101"))
print("best alternating:", alt, "| QUBO minimizer official:", C[qa], f"regret={(C[qa]-Cs)/Cs:.2%}", f"| sim evals used={n}")
for p in (1, 2, 3, 4):
    lifts, enr = [], []
    for s in seeds:
        _, cnt, _ = run_qaoa_pipeline(sc, Q, off, seed=s, p=p)
        EQ = sum(v * C[int(k, 2)] for k, v in cnt.items()) / 4096
        lifts.append((Cr - EQ) / (Cr - Cs)); enr.append(sum(v for k, v in cnt.items() if int(k, 2) in elite) / 4096 / (13 / 256))
    print(f"p={p}: lift min={min(lifts):.3f} mean={np.mean(lifts):.3f} | enrichment min={min(enr):.2f} mean={np.mean(enr):.2f}")
